CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT DEFAULT 'buyer'
);

CREATE TABLE kyc (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  id_type TEXT,
  id_number TEXT,
  address TEXT,
  id_image_url TEXT,
  selfie_url TEXT,
  status TEXT DEFAULT 'pending'
);

CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  title TEXT,
  description TEXT,
  price NUMERIC,
  category TEXT,
  image_url TEXT,
  location TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE transactions (
  id SERIAL PRIMARY KEY,
  buyer_id INTEGER REFERENCES users(id),
  seller_id INTEGER REFERENCES users(id),
  product_id INTEGER REFERENCES products(id),
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE disputes (
  id SERIAL PRIMARY KEY,
  transaction_id INTEGER REFERENCES transactions(id),
  user_id INTEGER REFERENCES users(id),
  message TEXT,
  status TEXT DEFAULT 'open',
  admin_note TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
