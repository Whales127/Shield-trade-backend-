const express = require('express');
const router = express.Router();
const pool = require('../db');
const jwt = require('jsonwebtoken');
const jwtSecret = process.env.JWT_SECRET;

function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).send('No token');
  try {
    req.user = jwt.verify(token, jwtSecret);
    next();
  } catch {
    res.status(401).send('Invalid token');
  }
}

router.post('/submit', auth, async (req, res) => {
  const { idType, idNumber, address, idImageUrl, selfieUrl } = req.body;
  await pool.query(
    'INSERT INTO kyc (user_id, id_type, id_number, address, id_image_url, selfie_url, status) VALUES ($1, $2, $3, $4, $5, $6, $7)',
    [req.user.id, idType, idNumber, address, idImageUrl, selfieUrl, 'pending']
  );
  res.send('KYC submitted');
});

router.get('/my', auth, async (req, res) => {
  const result = await pool.query('SELECT * FROM kyc WHERE user_id = $1', [req.user.id]);
  res.json(result.rows);
});

module.exports = router;
